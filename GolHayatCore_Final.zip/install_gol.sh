#!/data/data/com.termux/files/usr/bin/bash
echo "[*] نصب GolHayatCore در حال اجراست..."

pkg update -y && pkg upgrade -y
pkg install -y python git wget unzip figlet

cd ~/GolHayatCore_Final || exit

# اجرای هسته
python gol_hayat_core.py
