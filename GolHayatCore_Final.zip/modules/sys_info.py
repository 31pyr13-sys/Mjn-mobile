import platform

def system_info():
    print("سیستم‌عامل:", platform.system())
    print("ورژن:", platform.version())
    print("پردازنده:", platform.processor())
