import os

def scan_network():
    print("[*] اسکن شبکه در حال اجرا...")
    os.system("ping -c 4 8.8.8.8")
