# 🌸 GolHayatCore_Final 🌸

یک هسته‌ی سبک، ماژولار و خود-تکاملی برای اجرای پروژه‌ها در Termux.

## نصب سریع:
```bash
cd ~ && \
wget -O GolHayatCore_Final.zip "https://raw.githubusercontent.com/31pyr13-sys/Gol/main/GolHayatCore_Final.zip" && \
unzip -o GolHayatCore_Final.zip -d GolHayatCore_Final && \
cd GolHayatCore_Final && \
chmod +x install_gol.sh && \
./install_gol.sh
```

## قابلیت‌ها
- مدیریت پروژه‌ها (افزودن، تکامل، نمایش).
- داشبورد ASCII رنگی و زنده.
- ماژول‌های شبکه، سیستم، هوش یادگیرنده.
- توسعه‌پذیر و قابل ارتقا برای هر پروژه جدید.
