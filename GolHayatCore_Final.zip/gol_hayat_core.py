import os, json, time, random
from datetime import datetime

PROJECTS_FILE = "projects.json"

def load_projects():
    if not os.path.exists(PROJECTS_FILE):
        return {}
    with open(PROJECTS_FILE, "r") as f:
        return json.load(f)

def save_projects(data):
    with open(PROJECTS_FILE, "w") as f:
        json.dump(data, f, indent=2)

def add_project(name):
    projects = load_projects()
    projects[name] = {"growth": 1, "created": str(datetime.now())}
    save_projects(projects)

def evolve_projects():
    projects = load_projects()
    for p in projects:
        projects[p]["growth"] += 1
    save_projects(projects)

def dashboard():
    os.system("clear")
    print("=== داشبورد اکوسیستم گل حیات ===")
    projects = load_projects()
    print(f"تعداد پروژه‌ها: {len(projects)}")
    for name, info in projects.items():
        print(f"- {name} | مرحله رشد: {info['growth']}")
    print("===============================\n")

def main():
    while True:
        dashboard()
        print("1. افزودن پروژه جدید")
        print("2. تکامل پروژه‌ها")
        print("3. اجرای داشبورد پیشرفته")
        print("4. خروج")

        choice = input("> ")
        if choice == "1":
            name = input("نام پروژه: ")
            add_project(name)
        elif choice == "2":
            evolve_projects()
        elif choice == "3":
            os.system("python gol_hayat_dashboard.py")
        elif choice == "4":
            break

if __name__ == "__main__":
    main()
