import os, json, time

PROJECTS_FILE = "projects.json"

def load_projects():
    if not os.path.exists(PROJECTS_FILE):
        return {}
    with open(PROJECTS_FILE, "r") as f:
        return json.load(f)

def ascii_bar(level, max_level=10):
    filled = "█" * level
    empty = "-" * (max_level - level)
    return f"[{filled}{empty}]"

def dashboard():
    os.system("clear")
    print("🌸🌌 داشبورد گرافیکی گل حیات 🌌🌸\n")
    projects = load_projects()
    for name, info in projects.items():
        bar = ascii_bar(info["growth"] % 10)
        print(f"{name:<15} | رشد: {info['growth']} | {bar}")
    print("\n====================================")

if __name__ == "__main__":
    while True:
        dashboard()
        time.sleep(2)
